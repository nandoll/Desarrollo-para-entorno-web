class EmailValidator < ActiveModel::EachValidator
    def validate_each(record, attribute, value)
      unless value =~ /\A([^@\s]+)@((?:[-a-z0-9]+\.)+[a-z]{2,})\z/i
        record.errors[attribute] << (options[:message] || "No es un correo válido")
      end
    end
  end
  
class Persona < ApplicationRecord
    validates :dni, :nombre, :apellido, :correo, :salario, presence:true
    # validar por longitud
    validates :dni, length:{
        is: 8,
        message: 'El DNI debe tener 8 dígitos'
    }
    validates :nombre, :apellido, length:{
        minimum: 2,
        maximum: 15,
        too_short: 'No puede contener %{count} caractéres',
        too_long: 'No puede contener más de %{count} caractéres'
    }
    
    #unico
    validates :dni, uniqueness:{
        message: 'El DNI ya se encuentra registrado'
    }

    validates :dni, :edad, numericality:{
        only_integer: true,
        message: 'Debe ser númerico'
    }
    #solo letras
    validates :nombre, :apellido, format:{
        with: /\A[a-zA-Z ]+\z/,
        message: 'Solo letras'
    }

    #correo
    validates :correo, email:{
        message: 'No es un correo válido'
    }
    
end
