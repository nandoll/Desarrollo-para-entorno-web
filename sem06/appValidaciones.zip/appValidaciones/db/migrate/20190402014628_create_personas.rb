class CreatePersonas < ActiveRecord::Migration[5.2]
  def change
    create_table :personas do |t|
      t.string :dni, limit: 8
      t.string :nombre, limit: 50
      t.string :apellido, limit: 50
      t.integer :edad
      t.string :correo
      t.decimal :salario
      t.decimal :salario

      t.timestamps
    end
  end
end
