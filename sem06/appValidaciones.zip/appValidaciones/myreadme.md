#crear el scaffold
rails g scaffold persona 
dni:string{8} 
nombre:string{50} 
apellido:string{50} 
edad:integer 
correo:string:string{50} 
salario:decimal:decimal{10,2}

#Validaciones

igual que el scaffold al final presence true



rails g scaffold producto codigo:string{5} nombre:string{10} cantidad:integer precio:decimal{15,2}
